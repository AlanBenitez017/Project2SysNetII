#include "Server.hpp"

using namespace std;

int main(){

    Server();

    return 0;
}